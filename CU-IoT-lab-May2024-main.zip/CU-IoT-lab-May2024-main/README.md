# Introduction 
A hands-on lab for those beautiful minds willing to learn how easy it can be to build a basic E2E IoT setup in AWS

# Getting Started
Two pipelines to be built:

- YAML
- classic one as Releases


YAML one builds the infra base for the whole lab and the classic one is used to demonstrate the IoT/system part. Whole setup will be build with Terraform on a connected AWS account.

# Build and Test
One YAML stage: Building initial infra setup for Terraform needs (S3 + DynamoDB)
If additional stage added, then in the YAML the control on the stages is maintained via a variable buildType.
In the classic pipeline there is no triggering, thus there is need to manually run each of stages.
The rest is explained in a presentation released separately.

