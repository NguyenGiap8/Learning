import json
import boto3
import time

# Initialize IoT Data client for the 'eu-central-1' region
client = boto3.client('iot-data', region_name='eu-central-999')   # Set incorrectly on purpose. Change to your chosen region.

# Initialize DynamoDB resource
dynamodb = boto3.resource('dynamodb')

# Define the Lambda handler function
def lambda_handler(event, context):
    source = "lambda_dyndb"  # Define the source identifier for the Lambda function
    incoming_source = event['state']['reported']['source']  # Extract the source from the incoming event
    tablename = '<dynamodb_name>'  # Enter the DynamoDB table name created in lambda_dyndb.tf file, eg. 'lab-dynamodb-666'
    table = dynamodb.Table(tablename)  # Get the DynamoDB table resource

    # Check if there is a reported state in the event
    if event['state']['reported']:
        # Only process the event if the incoming source is different from the Lambda's source
        if incoming_source != source:
            timestamp = int(time.time())  # Get the current timestamp
            temperature = event['state']['reported']['temperature']  # Extract the reported temperature
            unitstate = event['state']['reported']['unit state']  # Extract the reported unit state
            thingid = event['state']['reported']['thingid']  # Extract the reported thing ID

            # Put the item into the DynamoDB table
            table.put_item(
                Item={
                    "thingId": thingid,  # Partition key
                    "temperature": temperature,  # Temperature value
                    "unit state": unitstate,  # Unit state
                    "timestamp": timestamp  # Current timestamp
                }
            )


"""
Example of a JSON payload for this lambda:

{
    "state": {
        "reported": {
            "temperature": 24,
            "unit state": "idling",
            "thingid" : "lab-thing-611",
            "source": "lab-thing-611"
            }
        }
    }

"""