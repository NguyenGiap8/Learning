# Importing the necessary libraries
import ssl  # For handling SSL/TLS encryption
import time  # For handling time-related tasks
import json  # For handling JSON data
import argparse  # For parsing command-line arguments
import random  # For generating random numbers
import paho.mqtt.client as mqtt  # For MQTT communication
from paho.mqtt.properties import Properties  # For handling MQTT properties
from paho.mqtt.packettypes import PacketTypes  # For handling MQTT packet types
from tqdm import tqdm  # For displaying progress bars

# Define the AWS IoT Core endpoint, device name, and paths to the certificate files
AWS_ENDPOINT = ""  # Set incorrectly on purpose. Change to your endpoint. Example: "b4oo5r3ype78nq-ats.iot.eu-west-1.amazonaws.com"
DEVICE_NAME = ""  # Set incorrectly on purpose. Change to your thing name as defined in iot.tf file. Example: "lab-thing-666"
CERT_FILE = "client-certificate.pem.crt"  # Ensure the certificate generated as part of iot.tf file has been saved here.
KEY_FILE = "client-private.pem.key"  # Ensure the key generated as part of iot.tf file has been saved here.
ROOT_CA_FILE = "AmazonRootCA1.pem" #Ensure the downloaded Amazon Root CA file has been saved here,

# Initialize variables
unitstate = "idling"
desired_unitstate = "idling"
end_listen_time = 0
desired_temperature = 18
temperature = 18
version = 0

# Function to handle incoming messages from AWS IoT Core
def on_message(client, userdata, message):
    global unitstate
    global end_listen_time
    global desired_temperature
    global temperature
    global desired_unitstate
    global version

    # Decode the incoming message payload
    string_message = str(message.payload.decode())

    # Handle messages on delta topic
    #print(f"Received message on topic {message.topic}: {string_message}")
    if "delta" in message.topic:
        decoded_message = json.loads(message.payload.decode())
        
        # Update desired temperature
        if "temperature" in string_message:
            desired_temperature = decoded_message['state']['temperature']
            
        # Update unit state
        if "unit state" in string_message:
            print("-------------THE CLOUD-------------")
            version = decoded_message['version']
            unitstate = decoded_message['state']['unit state']
            desired_unitstate = unitstate
            print(f"Version: {version}")
            print(f"Set the unit state to {desired_unitstate}")
            print("-----------------------------------")
            print("")

def main(active, num_messages, interval, mprotocol, tprotocol):
    # Define variables exchanges with callbacks
    global unitstate
    global end_listen_time
    global desired_temperature
    global desired_unitstate
    global temperature
    global version

    print("")
    print("------------IOT SIMULATOR----------")
    print(f"Iot Thing: {DEVICE_NAME}")
    print(f"Active device: {active}")
    print(f"MQTT version: {mprotocol}")
    print(f"Transport protocol: {tprotocol}")
    print(f"Number of messages: {num_messages}")
    print(f"Messages interval: {interval}")
    print("-----------------------------------")
    print("")

    # Initialize MQTT client
    if mprotocol == '5':
        client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id=DEVICE_NAME, transport=tprotocol, protocol=mqtt.MQTTv5)
    else:
        client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id=DEVICE_NAME, transport=tprotocol, protocol=mqtt.MQTTv311, clean_session=True)
    
    # Set TLS parameters for the client
    client.tls_set(ROOT_CA_FILE, certfile=CERT_FILE, keyfile=KEY_FILE, cert_reqs=ssl.CERT_REQUIRED, tls_version=ssl.PROTOCOL_TLSv1_2, ciphers=None)

    # Set callbacks
    client.on_message = on_message
    # If you want implement further callbacks, separate for each type of message.
    """
    client.on_connect = on_connect
    client.on_publish = on_publish
    client.on_subscribe = on_subscribe
    """

    # Connect to AWS IoT Core
    if tprotocol == 'tcp':
        mport = 8883
    else:
        mport = 443
    client.connect(AWS_ENDPOINT, mport)

    # Start the MQTT client loop
    client.loop_start()

    # Subscribe to all topics related to the device and its shadows. QoS is set to 2
    client.subscribe(f"$aws/things/{DEVICE_NAME}/shadow/update/delta")
    client.subscribe(f"$aws/things/{DEVICE_NAME}/shadow/update/accepted")
    client.subscribe(f"$aws/things/{DEVICE_NAME}/shadow/update/rejected")

    # Publish messages periodically
    if active:
        i = 0
        while i < num_messages:
            # Generate a random temperature with some chance for going too high or too low
            anomaly_change = 0
            if unitstate == "cooling":
                temperature -= 2
            elif unitstate == "heating":
                temperature += 2
            else:
                temperature = 18 + (random.randrange(5) % 3)
            
            anomaly_prob = (random.randrange(200) % 100)
            anomaly_sign_prob = (random.randrange(200) % 100)
            
            if anomaly_prob > 75 and unitstate == "idling":
                anomaly_change = random.randrange(10)
            elif anomaly_prob > 90 and unitstate != "idling":
                anomaly_change = random.randrange(5)
            
            if anomaly_change:
                if anomaly_sign_prob > 50:
                    temperature += anomaly_change
                else:
                    temperature -= anomaly_change
            
            # Publish the value to the request topic
            """
            properties = Properties(PacketTypes.PUBLISH)
            properties.MessageExpiryInterval = 30 
            """
            print("----------SIMULATED DEVICE---------")
            print(f"Version: {version}")
            print(f"Sensor's temperature: {temperature}")
            print(f"Sensor's state: {unitstate}")
            print(f"Requested temperature: {desired_temperature}")
            print(f"Requested state: {desired_unitstate}")
            print("-----------------------------------")
            print("")

            client.publish(f"$aws/things/{DEVICE_NAME}/shadow/update", json.dumps({"state": {"reported": {"temperature": temperature, "unit state": unitstate, "thingid": DEVICE_NAME, "source": DEVICE_NAME}}}))
            #print(f"Published message: {temperature} , {unitstate}")
            # Wait for the specified interval
            time.sleep(interval)
            i += 1

    # Keep the script running for 5 more minutes to listen for incoming messages
    end_listen_time = time.time() + 300
    with tqdm(total=300, desc='Listening for MQTT messages from the AWS IoT Core') as pbar:
        while time.time() < end_listen_time:
            # Update progress bar
            pbar.update(1)
            time.sleep(1)

    # Stop the MQTT client loop
    client.loop_stop()
    client.disconnect()

if __name__ == "__main__":
    # Parse command line arguments
    parser = argparse.ArgumentParser(description="IoT Device Simulation Script")
    parser.add_argument("--active", type=int, default=0, help="Listener (0) or an active device (1)")
    parser.add_argument("--num_messages", type=int, default=5, help="Number of messages to publish")
    parser.add_argument("--interval", type=int, default=15, help="Interval between messages in seconds")
    parser.add_argument("--mprotocol", type=str, default='5', help="MQTT version: 5 or 3")
    parser.add_argument("--tprotocol", type=str, default='tcp', help="Transport: websocket or tcp")
    args = parser.parse_args()

    # Run the main function with parsed arguments
    main(args.active, args.num_messages, args.interval, args.mprotocol, args.tprotocol)
