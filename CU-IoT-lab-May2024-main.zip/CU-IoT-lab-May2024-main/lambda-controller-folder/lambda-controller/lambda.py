import json
import boto3

# Initialize a client for AWS IoT Data with the specified region
client = boto3.client('iot-data', region_name='eu-central-999') # Set incorrectly on purpose. Change to your chosen region.

def lambda_handler(event, context):
    # Define the source identifier for this Lambda function
    source = "lambda_tempc"
    # Extract the source from the incoming message
    incoming_source = event['state']['reported']['source']
    
    # Check if there is reported state data in the incoming message
    if event['state']['reported']:
        # Ensure that the message did not originate from this Lambda function
        if incoming_source != source:
            # Define temperature control thresholds and the default desired temperature
            desired_temp = 18
            too_high = 25
            too_low = 15
            # Extract the temperature, unit state, and thing ID from the reported state
            temperature = event['state']['reported']['temperature']
            unitstate = event['state']['reported']['unit state']
            thingid = event['state']['reported']['thingid']
            
            # Determine the new unit state based on the temperature
            if temperature > too_high:
                unitstate = "cooling"  # If the temperature is too high, set the unit to cooling
            elif temperature < too_low:
                unitstate = "heating"  # If the temperature is too low, set the unit to heating
            else:
                unitstate = "idling"   # If the temperature is within the acceptable range, set the unit to idling
            
            # Publish the desired state to the AWS IoT shadow update topic
            response = client.publish(
                topic=f"$aws/things/{thingid}/shadow/update",
                qos=1,
                payload=json.dumps({"state": {"desired": {"temperature": desired_temp, "unit state": unitstate, "source": source}}})
            )
            # Print the response from the publish action
            print(response)
            
            # Return a success response
            return {
                'statusCode': 200,
                'body': json.dumps(f"Published to $aws/things/{thingid}/shadow/update topic")
            }


"""
Example of a JSON payload for this lambda:

{
    "state": {
        "reported": {
            "temperature": 24,
            "unit state": "idling",
            "thingid" : "lab-thing-611",
            "source": "lab-thing-611"
            }
        }
    }

"""